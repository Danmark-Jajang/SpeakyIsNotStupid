import rumps
import os
import sys

class speaki_cry(rumps.App):
    def __init__(self):
        super(speaki_cry, self).__init__("Speaki")
        
        # 앱으로 패키징되었을 때 리소스 경로 찾기
        if getattr(sys, 'frozen', False):
            # 패키징된 앱
            bundle_dir = os.path.dirname(sys.executable)
            resource_dir = os.path.join(bundle_dir, '..', 'Resources')
        else:
            # 개발 중
            resource_dir = os.path.dirname(__file__)
        
        self.icons = [
            os.path.join(resource_dir, f"speaki_{i}.png") 
            for i in range(1, 7)
        ]
        
        self.icon = self.icons[0]  # 초기 아이콘 설정
        self.menu = ["Quit"]
        self.is_crying = True
        self.animation_frame = 0  # 0부터 시작하는게 더 자연스러움

    @rumps.timer(0.1)
    def update_icon(self, _):
        if self.is_crying:
            self.icon = self.icons[self.animation_frame % len(self.icons)]
            self.animation_frame += 1

if __name__ == "__main__":
    app = speaki_cry()
    app.run()